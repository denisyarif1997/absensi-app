@extends('layouts.base')

@section('base')

@yield('content')

@endsection