<div class="d-flex align-items-center" style="padding-left: 10px;">
    <div wire:loading class="spinner-border" role="status" style="color: #656363;">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
<?php /**PATH C:\Webproject\Laravel\absensi-app\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/frameworks/bootstrap5/header/loading.blade.php ENDPATH**/ ?>